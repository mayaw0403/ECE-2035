//=================================================================
// Copyright 2022 Georgia Tech.  All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must not be made publicly available anywhere.
//=================================================================

#include <stdio.h>
#include <stdlib.h>

/* 
 Student Name: Maya Williams
 Date: September 7, 2022

ECE 2035 Homework 1-2

This is the only file that should be modified for the C implementation
of Homework 1.

Do not include any additional libraries.

This program computes the Intersection over Union of two rectangles
as an integer representing a percent:
                 Area(Intersection of R1 and R2) * 100
  IoU =    -----------------------------------------------------
           Area(R1) + Area(R2) - Area(Intersection of R1 and R2)

Assumptions for this homework:	
  1. R1 and R2 do overlap (Area of intersection of R1 and R2 != 0)
  2. only R1's bottom left corner is inside R2, and only R2's top
     right corner is inside R1.	

Input: two bounding boxes, each specified as {Tx, Ty, Bx, By), where
	 (Tx, Ty) is the upper left corner point and
	 (Bx, By) is the lower right corner point.
       These are given in two global arrays R1 and R2.
Output: IoU (an integer, 1 <= IoU < 100).

IoU should be specified as an integer (only the whole part of the division),
i.e., round down to the nearest whole number between 1 and 100 inclusive.

FOR FULL CREDIT (on all assignments in this class), BE SURE TO TRY
MULTIPLE TEST CASES and DOCUMENT YOUR CODE.
*/

//DO NOT change the following declaration (you may change the initial value).
// Bounding box: {Tx, Ty, Bx, By}
int R1[] = {55, 40, 130, 190};
int R2[] = {20, 50, 220, 330};
int IoU;

/*
For the grading scripts to run correctly, the above declarations
must be the first lines of code in this file (for this homework
assignment only).  Under penalty of grade point loss, do not change
these lines, except to replace the initial values while you are testing
your code.  

Also, do not include any additional libraries.
 */

int main() {

  // insert your code here

  int AreaR1 = ((R1[2] - R1[0]) * (R1[3] - R1[1])); //To find R1 Area, you mulitply the difference of Bx and Tx (Bx-Tx) by the difference of By and Ty (By-Ty) **note the array positions
  int AreaR2 = ((R2[2] - R2[0]) * (R2[3] - R2[1])); //To find R2 Area, you mulitply the difference of Bx and Tx (Bx-Tx) by the difference of By and Ty (By-Ty) **note the array positions

  int AreaR3 = ((R2[2] - R1[0]) * (R1[3] - R2[1])); //To find intersection Area, you mulitply the difference of Bx and Tx (R2 Bx - R1 Tx) by the difference of By and Ty (R1 By - R2 Ty) **note the array positions

  IoU = (AreaR3 * 100) / (AreaR1 + AreaR2 - (AreaR3));  //Mulitply the interesection area by 100 before dividing it by the value in the denomintor, which is R1 plus R2 minus the intersection area value

  printf("Intersection over Union: %d%%\n", IoU); //print out the intersection over union value as a integer percentage between 1-100
  return 0;
}



