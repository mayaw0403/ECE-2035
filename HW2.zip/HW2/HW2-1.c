//=================================================================
// Copyright 2022 Georgia Tech.  All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must not be made publicly available anywhere.
//=================================================================

/* Image Compare

Please fill in the following
Your Name: Maya Williams
Date: September 14, 2022

ECE 2035 Homework 2-1

This is the only file that should be modified for the C implementation
of Homework 2.

Do not include any additional libraries.

FOR FULL CREDIT (on all assignments in this class), BE SURE TO TRY
MULTIPLE TEST CASES and DOCUMENT YOUR CODE.

-----------------------------------------------

Image Compare 

This program takes in two 32x32 image arrays (read from given input files)
and computes a 3rd image array that is the result of comparing the two
input images.  The comparison between two pixels is done by computing
the sum of absolute differences (or SAD) of the pixels' color components:
   SAD = | A_r - B_r | + | A_g - B_g | + | A_b - B_b |
where each subscript indicates the red, green or blue component of color A or B.

Each pixel P_i of the resulting comparison image is set to a different fully
saturated color value (white, blue, green, or red), depending on the degree of
difference in the corresponding i_th pixels in the input images:
 white if 0 <= SAD < 100,
 blue  if 100 <= SAD < 200, 
 green if 200 <= SAD < 300, 
 red   if 300 <= SAD < 766

The output of this program is a print out of the elements of the Result image 
array using the print statement provided.
*/

#include <stdio.h>
#include <stdlib.h>

#define DEBUG 0 // RESET THIS TO 0 BEFORE SUBMITTING YOUR CODE

#define BLUE  0x0000FF
#define GREEN 0x00FF00
#define RED   0xFF0000
#define WHITE 0xFFFFFF

int  Load_Mem(char *, int *, int *);

int main(int argc, char *argv[]) {
  /* you may change and add to these declarations and initializations */
  int	ImageA[1024];
  int	ImageB[1024];
  int	Result[1024];
  int	N, Num;

  int Ar = 0;
  int Ag = 0;
  int Ab = 0;
  int Br = 0;
  int Bg = 0;
  int Bb = 0;
  int Sad = 0;

  if (argc != 2) {
    printf("usage: ./HW2-1 valuefile\n");
    exit(1);
  }
  Num = Load_Mem(argv[1], ImageA, ImageB);
  if (Num != 2048) {
    printf("value file must contain 2048 entries\n");
    exit(1);
  }

  for(N = 0; N < 1024; N++) {
    
    /* Your program goes here. */
    Ar = (ImageA[N] >>16) & 0xFF; //get the Image A pixel red by shifting 16 and masking the blue
    Ag = (ImageA[N] >>8) & 0xFF; //get the Image A pixel green by shifting 8 and masking the blue
    Ab = (ImageA[N]) & 0xFF; //get the Image A pixel blue by masking the blue

    Br = (ImageB[N] >>16) & 0xFF; //get the Image B pixel red by shifting 16 and masking the blue
    Bg = (ImageB[N] >>8) & 0xFF; //get the Image B pixel green by shifting 8 and masking the blue
    Bb = (ImageB[N]) & 0xFF; //get the Image B pixel blue by masking the blue

    Sad = abs(Ar - Br) + abs(Ag - Bg) + abs(Ab - Bb); //computing the sum of absolute difference using the given SAD formula



    if ((Sad >= 0) && (Sad < 100)) {
      Result[N] = WHITE; //if SAD is greater than or equal to 0 and less than 100, the result will be white
    }
    else if ((Sad >= 100) && (Sad < 200)){
      Result[N] = BLUE; //if SAD is greater than or equal to 100 and less than 200, the result will be blue
    }
    else if ((Sad >= 200) && (Sad < 300)){
      Result[N] = GREEN; //if SAD is greater than or equal to 200 and less than 300, the result will be green
    }
    else if ((Sad >= 300) && (Sad < 766)){
      Result[N] = RED; //if SAD is greater than or equal to 300 and less than 766, the result will be red
    }

    /* your program should use this print statement for each Result pixel. */
    printf("%4d: %8d\n", N, Result[N]);

    /* Sample debugging print statement. */
    if (DEBUG){
      if (N%16 == 0) printf("Example: N is %d.\n", N);
    }
  }

  /* Use a statement like this to print information helpful to
     debugging (e.g., the current value of some variable).
  */
  if (DEBUG){
    printf("Sample debugging print statement. argc: %d \n", argc);
    printf("These will only show up when DEBUG is set to 1.\n");
    printf("You should wrap DEBUG around any debugging print statements\n");
    printf("you add.  This makes it easy to turn them off so that your\n");
    printf("program doesn't confuse grading scripts with superfluous prints.\n"); 
    printf("You must set DEBUG to 0 before submitting your code.\n");
  }

  exit(0);
}

/* This routine loads in up to 2048 newline delimited integers from
a named file in the local directory. The values are placed in the
passed integer array. The number of input integers is returned. */

int Load_Mem(char *InputFileName, int IntArray1[], int IntArray2[]) {
   int	N, Addr, Value, NumVals;
   FILE	*FP;

   FP = fopen(InputFileName, "r");
   if (FP == NULL) {
     printf("%s could not be opened; check the filename\n", InputFileName);
     return 0;
   } else {
     for (N=0; N < 2048; N++) {
       NumVals = fscanf(FP, "%d: %d", &Addr, &Value);
       if (NumVals == 2)
	 if (N<1024) // first 1024 values go into IntArray1
	   IntArray1[N] = Value;
         else        // next 1024 go into int Array2
	   IntArray2[N-1024] = Value;
       else
	 break;
     }
     fclose(FP);
     return N;
   }
}
