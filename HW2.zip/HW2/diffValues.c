//=================================================================
// Copyright 2022 Georgia Tech.  All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must not be made publicly available anywhere.
//=================================================================

/* This program takes in two valuefiles each containing 1024 [Addr: Value]
pairs and compares the Values on corresponding lines. It prints the total
number of mismatched Values.
*/

#include <stdio.h>
#include <stdlib.h>

int  Load_Mem(char *, int *);

int main(int argc, char *argv[]) {
   int	ArrayA[1024];
   int	ArrayB[1024];
   int	N, NumA, NumB;
   int NumDiffs = 0;

   if (argc != 3) {
     printf("usage: ./diffValues valuefile1 valuefile2\n");
     exit(1);
   }
   NumA = Load_Mem(argv[1], ArrayA);
   NumB = Load_Mem(argv[2], ArrayB);
   if ((NumA != 1024) || (NumB != 1024)) {
     printf("value files must contain 1024 entries\n");
     exit(1);
   }

   for(N = 0; N < NumA; N++) {
     if (ArrayA[N] != ArrayB[N])
       NumDiffs++;
   }
   printf("%d value differences.\n", NumDiffs);
   exit(0);
}

/* This routine loads in up to 1024 newline delimited integers from
a named file in the local directory. The values are placed in the
passed integer array. The number of input integers is returned. */

int Load_Mem(char *InputFileName, int IntArray[]) {
   int	N, Addr, Value, NumVals;
   FILE	*FP;

   FP = fopen(InputFileName, "r");
   if (FP == NULL) {
     printf("%s could not be opened; check the filename\n", InputFileName);
     return 0;
   } else {
     for (N=0; N < 1024; N++) {
       NumVals = fscanf(FP, "%d: %d", &Addr, &Value);
       if (NumVals == 2)
	 IntArray[N] = Value;
       else
	 break;
     }
     fclose(FP);
     return N;
   }
}
