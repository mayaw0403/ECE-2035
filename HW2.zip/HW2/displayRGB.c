//=================================================================
// Copyright 2022 Georgia Tech.  All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must not be made publicly available anywhere.
//=================================================================

/* This program takes in an image file of 1024 [Addr: Value]
pairs. It displays the image as a color map or red, green, blue, white,
or yellow squares, depending on the Value in each pair which should
be either saturated R, G, or B, or white, or something else (an unknown
value).
*/

#include <stdio.h>
#include <stdlib.h>

/* PixelValues[i] and colors[i] should correspond to the same color.
   They specify which color display string to use for each image value.
   The last element of colors[] is used to display image values that
   do not occur in PixelValues[] (the unknown value case).
 */

unsigned PixelValues[] =
  {0x0000FF, // BLUE
   0x00FF00, // GREEN
   0xFF0000, // RED
   0xFFFFFF  // WHITE
  };

/* Colors used to display images.
https://en.wikipedia.org/wiki/ANSI_escape_code#Colors 
*/
const char *colors[] =
  {"\x1b[30;44m", // blue
   "\x1b[30;42m", // green
   "\x1b[30;41m", // red  
   "\x1b[30;47m", // white
   "\x1b[30;103m" // bright yellow
  };

#define RESET      "\x1b[0m"

int  Load_Mem(char *, int *);

/* Value is a pixel value from an image file.  Search for
   it in PixelValues and return index where it is found
   or if not found, return upper bound index (which is ==
   sizeof(PixelValues)) to indicate unknown pixel value.
 */
int LookupColorIndex(int Value){
  int i;
  for(i=0; i<(sizeof(PixelValues)/sizeof(unsigned)); i++)
    if (Value == PixelValues[i])
      return(i); // stop loop as soon as find value
  return(i);     // default: if not found return upper bound
}
  

int main(int argc, char *argv[]) {
   int	Image[1024];
   int  Num;
   if (argc != 2) {
     printf("usage: ./display imagefile\n");
     exit(1);
   }
   Num = Load_Mem(argv[1], Image);
   if (Num != 1024) {
     printf("image files must contain 1024 entries\n");
     exit(1);
   }

   char interval[6];
   int i, Value;
   int colorIndex;
   printf(" 0: ");
   for (i = 0; i<1024; i++) {
     Value = Image[i];
     colorIndex = LookupColorIndex(Value);
     snprintf(interval, sizeof(interval), "%%%dd", 3);
     printf("%s", colors[colorIndex]); // start highlighting in pixel's color
     printf(interval, i%32);
     printf(RESET); // stop highlighting
     if (i%32 == 31)
       printf("\n%2d: ", (i/32)+1);
   }
   printf("\n");
   return(0);
}

/* This routine loads in up to 1024 newline delimited integers from
a named file in the local directory. The values are placed in the
passed integer array. The number of input integers is returned. */

int Load_Mem(char *InputFileName, int IntArray[]) {
   int	N, Addr, Value, NumVals;
   FILE	*FP;

   FP = fopen(InputFileName, "r");
   if (FP == NULL) {
     printf("%s could not be opened; check the filename\n", InputFileName);
     return 0;
   } else {
     for (N=0; N < 1024; N++) {
       NumVals = fscanf(FP, "%d: %d", &Addr, &Value);
       if (NumVals == 2)
	 IntArray[N] = Value;
       else
	 break;
     }
     fclose(FP);
     return N;
   }
}
