//=================================================================
// The main program file.
//
// Copyright 2022 Georgia Tech. All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must NOT be made publicly available anywhere.
//==================================================================


// PROJECT INCLUDES
#include "globals.h"
#include "hardware.h"
#include "map.h"
#include "graphics.h"
#include "viper.h"

#include <math.h>
#include <stdio.h>

// Important definitions
#define NO_RESULT 0
#define NO_ACTION 0
#define ACTION_BUTTON 1
#define MENU_BUTTON 2
#define GO_LEFT 3
#define GO_RIGHT 4
#define GO_UP 5
#define GO_DOWN 6
#define GAME_OVER 7
#define FULL_DRAW 8
#define INVINCIBLE 9
#define DRAW_MENU 10
#define PAUSE_BUTTON 11
#define HARD_MODE 12
#define EASY_MODE 13
#define NORMAL_MODE 14

/////////////////////////////////////////////////////////////////////////////////////////

// GLOBAL VARS
Viper viper;
#define MENU 0
#define GAME 1
#define PAUSE 2
static int gameMode = MENU;
static int invincible = 0;
static int waittime = 100;

/////////////////////////////////////////////////////////////////////////////////////////

// FUNCTION PROTOTYPES
void playSound(char* wav);
int get_action(GameInputs inputs);
int update_game(int action);
void draw_upper_status();
void draw_lower_status();
void draw_border();
void draw_game(int draw_option);
void init_main_map();

/////////////////////////////////////////////////////////////////////////////////////////

// FUNCTION DEFINITIONS
/**
 * Plays a .wav file
 */
void playSound(char* wav)
{
    // OPTIONAL: Implement
    FILE* sound = fopen(wav, "r");
    waver.play(sound);
    fclose(sound);
    
}

/**
 * Given the game inputs, determine what kind of update needs to happen.
 * Possible return values are defined below.
 * Get Actions from User (pushbuttons, and nav_switch)
 * Based on push button and navigation switch inputs, determine which action
 * needs to be performed (may be no action).
 */
int get_action(GameInputs inputs)
{
    // TODO: Implement
    
    // 1. Check your action and menu button inputs and return the corresponding action value
    
    // 2. Check for your navigation switch inputs and return the corresponding action value
    
    // If no button is pressed, just return no action value
    switch(gameMode) {
        case MENU:
//            pc.printf("MENU\n");
            if (inputs.b1 == 1 && inputs.b2 == 1 && inputs.b3 == 0) {
                pc.printf("EASY\n");
                return EASY_MODE;
                }
            if (inputs.b1 == 1 && inputs.b2 == 0 && inputs.b3 == 1) {
                pc.printf("NORMAL\n");
                return NORMAL_MODE;
                }
            if (inputs.b1 == 0 && inputs.b2 == 1 && inputs.b3 == 1) {
                pc.printf("HARD\n");
                return HARD_MODE;
                }
            else return NO_ACTION;
        case GAME:
//            pc.printf("GAME\n");
            if (inputs.b1 == 1 && inputs.b2 == 1 && inputs.b3 == 0) {
                pc.printf("PAUSE\n");
                return PAUSE_BUTTON;
            }
            if (inputs.b1 == 1 && inputs.b2 == 0 && inputs.b3 == 1) {
                pc.printf("INVINCIBLE\n");
                return INVINCIBLE;
            }
            //if (inputs.ns_left == 0 && inputs.ns_up == 0) return NO_ACTION; 
            if (inputs.ns_up == 1){
                pc.printf("GO_UP\n");
                return GO_UP;
            } else if (inputs.ns_down == 1){
                pc.printf("GO_DOWN\n");
                return GO_DOWN;
            } else if (inputs.ns_left == 1){
                pc.printf("GO_LEFT\n");
                return GO_LEFT;
            } else if (inputs.ns_right == 1){
                pc.printf("GO_RIGHT\n");
                return GO_RIGHT;
            }
            
            if (inputs.b1 == 1){
                return ACTION_BUTTON;
            } else if (inputs.b2 == 1){
                return MENU_BUTTON;
            }
            
        case PAUSE:
//            pc.printf("PAUSE\n");
            if (inputs.b1 == 1 && inputs.b2 == 1 && inputs.b3 == 0) return PAUSE_BUTTON;
        default:
//            pc.printf("default\n");
            return NO_ACTION;
    }
}

/**
 * This function is called by update game to check when the snake 
 * gets an object (in other words, when a snake eats an object). We 
 * update the snake and game conditions as needed based on the object type
 */
 
 /*
int get_object(){
    
    //TODO: Implement
    
    // 1. Get item at current head location
    
    // 2. Initialize a return value variable to denote the item type we got
    
    // 3. Check if item is valid and is a chest
    //    3a. if so, increment the score, extend the length of the viper
    //    3b. Remove the chest
    //    3c. set the return value variable to GOT_LENGTH
    
    // 4. Else, check if the item is valid a boost-up/boost-down
    //    4a. if so, set the ability for the viper based on the type of item
    //          for the right amount fo time
    //    4b. Remove the boost-up/down item
    //    4c. Set the return value variable to GOT_OBJ
    //    Hint: You have to do this check for all your boost-ups/downs. Might be 
    //          easier to use Switch statements.
    
    // 5. Check if the return value variable is GOT_LENGTH
    //    5a. If so, then increase the snake length and update its locations as needed
    //        Hint: Refer to Step 6 below; the main difference is that you need 
    //        to lengthen the snake (what should we change the snake tail position to?)
    
    // 6. For any other object, do the following default steps
    //    6a. initialize two variables to to denote the original location for the x and y tail of the viper
    //    6b. For each location of the viper body, move them forward by one location
    //    6c. Update the initial viper location to the viper head x and y location
    //    6d. call a function to add a viper head given the head x and y location
    //    6e. call a function to add a viper body to the location after the head
    //    6f. call a function to add a viper tail to the location of the last viper locations
    //    6g. call a function to map erase the original location for the x and y tail
    //    6h. return the return value variable

    
}
*/

/**
 * Update the game state based on the user action. For example, if the user
 * requests GO_UP, then this function should determine if that is possible by
 * consulting the map, and update the viper position accordingly.
 * 
 * Return values are defined below. FULL_DRAW indicates that for this frame,
 * draw_game should not optimize drawing and should draw every tile, even if
 * the viper has not moved.
 */
 
 
int update_game(int action)
{
    MapItem* next;
    switch (action) {
        case EASY_MODE:
            waittime = 400;
            gameMode = GAME;
            return EASY_MODE;
        case NORMAL_MODE:
            waittime = 200;
            gameMode = GAME;
            return NORMAL_MODE;
        case HARD_MODE:
            waittime = 100;
            gameMode= GAME;
            return HARD_MODE;
        case PAUSE_BUTTON:
            
            if (gameMode == PAUSE)
                gameMode = GAME;
            else gameMode = PAUSE;
            return NO_ACTION;
                
        case INVINCIBLE : 
            invincible = !invincible;
            break;
        
        case GO_LEFT:
            if (gameMode == MENU || gameMode == PAUSE)
                return NO_ACTION;
            next = get_west(viper.head_x, viper.head_y);
            if (next->walkable) {
                switch (next->type) {
                    case CHEST:
                        viper.length += 1;
                        viper.score += 1;
                        break;
                    case BONUS:
                        viper.score = viper.score + 5;
                        draw_game(0);
                        break;
                    case VENOM:
                        viper.score -= 10;
                        if (viper.score <= 0) {
                            return GAME_OVER;
                        }
                        break;
                    case SPEED:
                        waittime /= 2;
                        break;
                    case SLOW:
                        waittime *= 2;
                        break;
                    default:
                        break;
                }
                return GO_LEFT;
            }
            return GAME_OVER;
        case GO_RIGHT:
            if (gameMode == MENU || gameMode == PAUSE)
                return NO_ACTION;
            next = get_east(viper.head_x, viper.head_y);
            if (next->walkable) {
                switch (next->type) {
                    case CHEST:
                        viper.length += 1;
                        viper.score += 1;
                        break;
                    case BONUS:
                        viper.score += 5;
                        break;
                    case VENOM:
                        viper.score -= 10;
                        if (viper.score <= 0) {
                            return GAME_OVER;
                        }
                        break;
                    case SPEED:
                        waittime /= 2;
                        break;
                    case SLOW:
                        waittime *= 2;
                        break;
                    default:
                        break;
                }
                return GO_RIGHT;
            }
            return GAME_OVER;
        case GO_UP:
            if (gameMode == MENU || gameMode == PAUSE)
                return NO_ACTION;
            next = get_north(viper.head_x, viper.head_y);
            if (next->walkable) {
                switch (next->type) {
                    case CHEST:
                        viper.length += 1;
                        viper.score += 1;
                        break;
                    case BONUS:
                        viper.score += 5;
                        break;
                    case VENOM:
                        viper.score -= 10;
                        if (viper.score <= 0) {
                            return GAME_OVER;
                        }
                        break;
                    case SPEED:
                        waittime /= 2;
                        break;
                    case SLOW:
                        waittime *= 2;
                        break;
                    default:
                        break;
                }
                return GO_UP;
            }
            return GAME_OVER;
        case GO_DOWN:
            if (gameMode == MENU || gameMode == PAUSE)
                return NO_ACTION;
            next = get_south(viper.head_x, viper.head_y);
            if (next->walkable) {
                switch (next->type) {
                    case CHEST:
                        viper.length += 1;
                        viper.score += 1;
                        break;
                    case BONUS:
                        viper.score += 5;
                        break;
                    case VENOM:
                        viper.score -= 10;
                        if (viper.score <= 0) {
                            return GAME_OVER;
                        }
                        break;
                    case SPEED:
                        waittime /= 2;
                        break;
                    case SLOW:
                        waittime *= 2;
                        break;
                    default:
                        break;
                }
                return GO_DOWN;
            }
            return GAME_OVER; 
        default:
            return NO_RESULT;
    } 
}


/**
 * Draw the upper status bar.
 */
void draw_upper_status()
{
    uLCD.line(0, 9, 127, 9, GREEN);
}

/**
 * Draw the lower status bar.
 */
void draw_lower_status()
{
    uLCD.line(0, 118, 127, 118, GREEN);
}

/**
 * Draw the border for the map.
 */
void draw_border()
{
    uLCD.filled_rectangle(  0,   9, 127,  14, WHITE);   // Top
    uLCD.filled_rectangle(  0,  13,   2, 114, WHITE);   // Left
    uLCD.filled_rectangle(  0, 114, 127, 117, WHITE);   // Bottom
    uLCD.filled_rectangle(124,  14, 127, 117, WHITE);   // Right
}

/**
 * Entry point for frame drawing. This should be called once per iteration of
 * the game loop. This draws all tiles on the screen, followed by the status
 * bars. Unless init is nonzero, this function will optimize drawing by only
 * drawing tiles that have changed from the previous frame.
 */
void draw_game(int draw_option)
{
    uLCD.locate(0,0);
    uLCD.printf("Pos:%i,%i Score:%i ", viper.head_x, viper.head_y, viper.score);
    // Draw game border first
    if(draw_option == FULL_DRAW) 
    {
        draw_border();
        int u = 58;
        int v = 56;
        draw_viper_head_E(u, v);
        draw_viper_body_H(u-11, v);
        draw_viper_tail_E(u-22, v);
        return;
    }

    // Iterate over all visible map tiles
    for (int i = -5; i <= 5; i++) { // Iterate over columns of tiles
        for (int j = -4; j <= 4; j++) { // Iterate over one column of tiles
            // Here, we have a given (i,j)

            // Compute the current map (x,y) of this tile
            int x = i + viper.head_x;
            int y = j + viper.head_y;

            // Compute the previous map (px, py) of this tile
            int px = i + viper.head_px;
            int py = j + viper.head_py;

            // Compute u,v coordinates for drawing
            int u = (i+5)*11 + 3;
            int v = (j+4)*11 + 15;

            // Figure out what to draw
            DrawFunc draw = NULL;
            if (x >= 0 && y >= 0 && x < map_width() && y < map_height()) { // Current (i,j) in the map
                MapItem* curr_item = get_here(x, y);
                MapItem* prev_item = get_here(px, py);
                if (draw_option || curr_item != prev_item) { // Only draw if they're different
                    if (curr_item) { // There's something here! Draw it
                        draw = curr_item->draw;
                    } else { // There used to be something, but now there isn't
                        draw = draw_nothing;
                    }
                } else if (curr_item && curr_item->type == CLEAR) {
                    // This is a special case for erasing things like doors.
                    draw = curr_item->draw; // i.e. draw_nothing
                }
            } else if (draw_option) { // If doing a full draw, but we're out of bounds, draw the walls.
                draw = draw_wall;
            }

            // Actually draw the tile
            if (draw) draw(u, v);
        }
    }

    // Draw status bars
    draw_upper_status();
    draw_lower_status();
}

/**
 * Initialize the main world map. Add walls around the edges, interior chambers,
 * and plants in the background so you can see motion.
 */
void init_main_map_easy()
{
    srand(time(NULL));
    // "Random" plants
    Map* map = set_active_map(0);
    for(int i = map_width() + 3; i < map_area(); i += 39) {
        add_plant(i % map_width(), i / map_width());
    }
    
    //generate at least 64 random chests
    for (int i = 0; i < 64; i++) {
        int r = rand() % map_area();
        add_chest(r % map_width(), r / map_width());
    }
    
    pc.printf("plants\r\n");
    
    //"Random" speed objects
    for (int i = 0; i < 6; i++) {
        int r = rand() % map_area();
        add_speed(r % map_width(), r / map_width());
    }
    pc.printf("speed\r\n");
    
    //"Random" slow objects
    for (int i = 0; i < 6; i++) {
        int r = rand() % map_area();
        add_slow(r % map_width(), r / map_width());
    }
    pc.printf("slow\r\n");
    
    //"Random" venom objects
    for (int i = 0; i < 6; i++) {
        int r = rand() % map_area();
        add_venom(r % map_width(), r / map_width());
    }
    pc.printf("venom\r\n");
    
    //"Random" bonus objects
    for (int i = 0; i < 6; i++) {
        int r = rand() % map_area();
        add_bonus(r % map_width(), r / map_width());
    }
    pc.printf("bonus\r\n");

    pc.printf("Adding walls!\r\n");
    add_wall(            0,              0, HORIZONTAL, map_width());
    add_wall(            0, map_height()-1, HORIZONTAL, map_width());
    add_wall(            0,              0,   VERTICAL, map_height());
    add_wall(map_width()-1,              0,   VERTICAL, map_height());
    pc.printf("Walls done!\r\n");
    
    //add_viper_head_E(viper.locations[0].x, viper.locations[0].y);
    //add_viper_body_H(viper.locations[1].x, viper.locations[1].y);
    //add_viper_tail_E(viper.locations[2].x, viper.locations[2].y);
    
    pc.printf("Add extra chamber\r\n");
    add_wall(30,  0,   VERTICAL, 10);
    add_wall(30, 10, HORIZONTAL, 10);
    add_wall(39,  0,   VERTICAL, 10);
    pc.printf("Added!\r\n");
    
    print_map();
}


void init_main_map_normal()
{
    srand(time(NULL));
    // "Random" plants
    Map* map = set_active_map(0);
    for(int i = map_width() + 3; i < map_area(); i += 39) {
        add_chest(i % map_width(), i / map_width());
    }
    
    //generate at least 64 random chests
    for (int i = 0; i < 64; i++) {
        int r = rand() % map_area();
        add_chest(r % map_width(), r / map_width());
    }
    
    pc.printf("plants\r\n");
    
    //"Random" speed objects
    for (int i = 0; i < 18; i++) {
        int r = rand() % map_area();
        add_speed(r % map_width(), r / map_width());
    }
    pc.printf("speed\r\n");
    
    //"Random" slow objects
    for (int i = 0; i < 6; i++) {
        int r = rand() % map_area();
        add_slow(r % map_width(), r / map_width());
    }
    pc.printf("slow\r\n");
    
    //"Random" venom objects
    for (int i = 0; i < 12; i++) {
        int r = rand() % map_area();
        add_venom(r % map_width(), r / map_width());
    }
    pc.printf("venom\r\n");
    
    //"Random" bonus objects
    for (int i = 0; i < 9; i++) {
        int r = rand() % map_area();
        add_bonus(r % map_width(), r / map_width());
    }
    pc.printf("bonus\r\n");

    pc.printf("Adding walls!\r\n");
    add_wall(            0,              0, HORIZONTAL, map_width());
    add_wall(            0, map_height()-1, HORIZONTAL, map_width());
    add_wall(            0,              0,   VERTICAL, map_height());
    add_wall(map_width()-1,              0,   VERTICAL, map_height());
    pc.printf("Walls done!\r\n");
    
    add_viper_head_E(viper.locations[0].x, viper.locations[0].y);
    add_viper_body_H(viper.locations[1].x, viper.locations[1].y);
    add_viper_tail_E(viper.locations[2].x, viper.locations[2].y);
    
    pc.printf("Add extra chamber\r\n");
    add_wall(30,  0,   VERTICAL, 10);
    add_wall(30, 10, HORIZONTAL, 10);
    add_wall(39,  0,   VERTICAL, 10);
    pc.printf("Added!\r\n");
    
    print_map();
}


void init_main_map_hard()
{
    srand(time(NULL));
    // "Random" plants
    Map* map = set_active_map(0);
    for(int i = map_width() + 3; i < map_area(); i += 39) {
        add_chest(i % map_width(), i / map_width());
    }
    
    //generate at least 64 random chests
    for (int i = 0; i < 64; i++) {
        int r = rand() % map_area();
        add_chest(r % map_width(), r / map_width());
    }
    
    pc.printf("plants\r\n");
    
    //"Random" speed objects
    for (int i = 0; i < 30; i++) {
        int r = rand() % map_area();
        add_speed(r % map_width(), r / map_width());
    }
    pc.printf("speed\r\n");
    
    //"Random" slow objects
    for (int i = 0; i < 3; i++) {
        int r = rand() % map_area();
        add_slow(r % map_width(), r / map_width());
    }
    pc.printf("slow\r\n");
    
    //"Random" venom objects
    for (int i = 0; i < 18; i++) {
        int r = rand() % map_area();
        add_venom(r % map_width(), r / map_width());
    }
    pc.printf("venom\r\n");
    
    //"Random" bonus objects
    for (int i = 0; i < 12; i++) {
        int r = rand() % map_area();
        add_bonus(r % map_width(), r / map_width());
    }
    pc.printf("bonus\r\n");

    pc.printf("Adding walls!\r\n");
    add_wall(            0,              0, HORIZONTAL, map_width());
    add_wall(            0, map_height()-1, HORIZONTAL, map_width());
    add_wall(            0,              0,   VERTICAL, map_height());
    add_wall(map_width()-1,              0,   VERTICAL, map_height());
    pc.printf("Walls done!\r\n");
    
    //add_viper_head_E(viper.locations[0].x, viper.locations[0].y);
    //add_viper_body_H(viper.locations[1].x, viper.locations[1].y);
    //add_viper_tail_E(viper.locations[2].x, viper.locations[2].y);
    
    pc.printf("Add extra chamber\r\n");
    add_wall(30,  0,   VERTICAL, 10);
    add_wall(30, 10, HORIZONTAL, 10);
    add_wall(39,  0,   VERTICAL, 10);
    pc.printf("Added!\r\n");
    
    print_map();
}


/**
 * Program entry point! This is where it all begins.
 * This function is for all the parts of the game. Most of your
 * implementation should be elsewhere - this holds the game loop, and should
 * read like a road map for the rest of the code.
 */
int main()
{
    // First things first: initialize hardware
    ASSERT_P(hardware_init() == ERROR_NONE, "Hardware init failed!");
    
    // 0. Initialize the maps
    // TODO: implement maps_init() and init_main_map() function in map.cpp:
    maps_init();

    while(1) {
        switch (gameMode) {
            case MENU:
                //draw_menu();
                uLCD.cls();
                uLCD.printf("\n\n\n       VIPER\n\n\n\n\n\n\n");
                uLCD.printf(" 1 - Easy \n\n 2 - Normal\n\n 3 - Hard");
                int result = NO_ACTION;
                while (result == NO_ACTION) {
                    GameInputs inputs = read_inputs();
                    int action = get_action(inputs);
                    int result = update_game(action);
                    if (result == EASY_MODE) {
                        init_main_map_easy();
                        set_active_map(0);
                        break;
                    }
                    if (result == NORMAL_MODE) {
                        init_main_map_normal();
                        set_active_map(0);
                        break;
                    }
                    if (result == HARD_MODE) {
                        init_main_map_hard();
                        set_active_map(0);
                        break;
                    }    
                }
                uLCD.cls();
                wait(.5);
                gameMode = GAME;
            case GAME:
                viper_init(&viper);
                // Initial drawing
                draw_game(FULL_DRAW);
                // Main game loop
                while (1) {   
                    int over = 0; 
                    // Timer to measure game update speed
                    Timer t;
                    t.start();
                    // 1. Read inputs 
                    //TODO: implement read_inputs() function in hardware.cpp:
                    GameInputs inputs = read_inputs();
                    
                    // 2. Determine action (move, act, menu, etc.)
                    //TODO: implement get_action() function:
                    int action = get_action(inputs);
                    pc.printf("%d\n", action);
                    // 3. Update game
                    //TODO: implement update_game() function:
                    int result = update_game(action);
            
                    // 3b. Check for game over based on result
                    // and if so, handle game over
                    //TODO: implement this here or as a new function.
                    //      3b1. if game is over, then
                    //      3b2. draw and display tezt for game over sign
                    int typ;
                    switch (result) {
                        case GO_LEFT:
                            //get rid of the tail
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->type = CLEAR;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->draw = draw_nothing;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->walkable = 1; 
                            viper.head_px = viper.head_x;
                            viper.head_py = viper.head_y;
                            viper.head_x = viper.head_x - 1;
                            add_viper_body_H(viper.head_px, viper.head_py);
                            add_viper_head_W(viper.head_x, viper.head_y);
                            for (int i = viper.length - 1; i > 0; i--) {
                                viper.locations[i].x = viper.locations[i - 1].x;
                                viper.locations[i].y = viper.locations[i - 1].y;
                                viper.locations[i].dir = viper.locations[i - 1].dir;
                            }
                            typ = TAIL_N + viper.locations[viper.length - 1].dir;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->type = typ;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->draw = tail(viper.locations[viper.length - 1].dir);
                            viper.locations[0].x = viper.head_x;
                            viper.locations[0].y = viper.head_y;
                            viper.locations[0].dir = 3;
                            break;
                        case GO_RIGHT:
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->type = CLEAR;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->draw = draw_nothing;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->walkable = 1; 
                            viper.head_px = viper.head_x;
                            viper.head_py = viper.head_y;
                            viper.head_x = viper.head_x + 1;
                            add_viper_body_H(viper.head_px, viper.head_py);
                            add_viper_head_E(viper.head_x, viper.head_y);
                            for (int i = viper.length - 1; i > 0; i--) {
                                viper.locations[i].x = viper.locations[i - 1].x;
                                viper.locations[i].y = viper.locations[i - 1].y;
                                viper.locations[i].dir = viper.locations[i - 1].dir;
                            }
                            typ = TAIL_N + viper.locations[viper.length - 1].dir;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->type = typ;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->draw = tail(viper.locations[viper.length - 1].dir);
                            viper.locations[0].x = viper.head_x;
                            viper.locations[0].y = viper.head_y;
                            viper.locations[0].dir = 1;
                            break;
                        case GO_DOWN:
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->type = CLEAR;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->draw = draw_nothing;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->walkable = 1; 
                            viper.head_px = viper.head_x;
                            viper.head_py = viper.head_y;
                            viper.head_y = viper.head_y + 1;
                            add_viper_body_V(viper.head_px, viper.head_py);
                            add_viper_head_S(viper.head_x, viper.head_y);
                            for (int i = viper.length - 1; i > 0; i--) {
                                viper.locations[i].x = viper.locations[i - 1].x;
                                viper.locations[i].y = viper.locations[i - 1].y;
                                viper.locations[i].dir = viper.locations[i - 1].dir;
                            }
                            typ = TAIL_N + viper.locations[viper.length - 1].dir;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->type = typ;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->draw = tail(viper.locations[viper.length - 1].dir);
                            viper.locations[0].x = viper.head_x;
                            viper.locations[0].y = viper.head_y;
                            viper.locations[0].dir = 2;
                            break;
                        case GO_UP:
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->type = CLEAR;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->draw = draw_nothing;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->walkable = 1; 
                            viper.head_px = viper.head_x;
                            viper.head_py = viper.head_y;
                            viper.head_y = viper.head_y - 1;
                            add_viper_body_V(viper.head_px, viper.head_py);
                            add_viper_head_N(viper.head_x, viper.head_y);
                            for (int i = viper.length - 1; i > 0; i--) {
                                viper.locations[i].x = viper.locations[i - 1].x;
                                viper.locations[i].y = viper.locations[i - 1].y;
                                viper.locations[i].dir = viper.locations[i - 1].dir;
                            }
                            typ = TAIL_N + viper.locations[viper.length - 1].dir;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->type = typ;
                            get_here(viper.locations[viper.length-1].x, viper.locations[viper.length-1].y)->draw = tail(viper.locations[viper.length - 1].dir);
                            viper.locations[0].x = viper.head_x;
                            viper.locations[0].y = viper.head_y;
                            viper.locations[0].dir = 0;
                            break;
                        case GAME_OVER:
                            if (!invincible) {
                                uLCD.cls();
                                uLCD.printf("\n\n\n\n\n     GAME OVER");
                                while (1) {
                                    wait(1);
                                }
                            }
                        default:
                            break;
                    }
                    
                    if (over) break;
                    
                    // 4. Draw screen -- provided.
                    draw_border();
                    draw_game(result);
            
                    // Compute update time
                    t.stop();
                    int dt = t.read_ms();
        
                    // Display and wait
                    // NOTE: Text is 8 pixels tall
                    if (dt < 100) wait_ms(100 - dt);
                }
                break;
            case PAUSE:
                uLCD.locate(0,119);
                uLCD.printf("PAUSED         ");
                while (1) {
                    if (!button3.read()) {
                        break;
                    }
                }
                draw_game(0);
                gameMode = GAME;
                break;
            default:
                break;
        }
    }
}